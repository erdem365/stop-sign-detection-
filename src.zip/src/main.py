"""
main.py
--------
Dataset içerisindeki tüm görselleri işlemek, sonuçları terminale yazdırmak,
işaretlenmiş cıktıları kaydetmek ve özet bir sonuç raporu (results.json)
üretmek için giriş noktası.

Kullanım:
    python src/main.py
    python src/main.py --dataset path/to/dataset --output path/to/outputs

HSV eşiklerini kod degistirmeden ayarlamak için (gercek dataset'e gore
kalibrasyon yaparken kullanışlıdır):
    python src/main.py --lower-red1 0 120 80 --upper-red1 8 255 255

Maskeyi de görmek için (HSV ayari yaparken hangi bölgelerin "kırmızı"
sayıldiığını incelemek amacıyla):
    python src/main.py --debug-mask
"""

import argparse
import json
import sys
from pathlib import Path
from typing import List, Tuple

import cv2

# main.py hem "python src/main.py" hem de "python -m src.main" ile
# calıştırılabilsin diye proje kökünü path'e ekliyoruz.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.config import DEFAULT_CONFIG, DetectionConfig  # noqa: E402
from src.detector import detect_stop_sign_debug, draw_detection  # noqa: E402

SUPPORTED_EXTENSIONS = {".jpg", ".jpeg", ".png"}


def find_dataset_images(dataset_dir: Path) -> List[Path]:
    """Dataset klasörünü (alt klasorler dahil) tarayıp desteklenen görselleri bulur."""
    if not dataset_dir.exists():
        return []
    return [
        p for p in sorted(dataset_dir.rglob("*"))
        if p.suffix.lower() in SUPPORTED_EXTENSIONS and p.is_file()
    ]


def process_dataset(
    dataset_dir: Path,
    output_dir: Path,
    config: DetectionConfig,
    save_debug_mask: bool = False,
) -> dict:
    """
    Dataset'teki her görüntüyü işler:
      1. Görüntüyü oku
      2. STOP tespitini yap
      3. Sonucu değerlendir
      4. Bounding box çiz
      5. Merkez koordinatını hesapla (detector içinde)
      6. Çıktıyı kaydet
      7. Terminale sonucu yazdır

    Dönen değer, sonradan rapor/README için kullanilabilecek özet istatistiktir.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    if save_debug_mask:
        (output_dir / "debug_masks").mkdir(parents=True, exist_ok=True)

    images = find_dataset_images(dataset_dir)

    summary = {
        "dataset_dir": str(dataset_dir),
        "total_images": len(images),
        "detected": 0,
        "not_detected": 0,
        "unreadable": 0,
        "per_image": [],
    }

    if not images:
        print(f"[UYARI] '{dataset_dir}' icerisinde desteklenen formatta "
              f"gorsel bulunamadi ({', '.join(sorted(SUPPORTED_EXTENSIONS))}).")
        print("Dataset'i 'dataset/' klasorune yerlestirip tekrar calistirin.")
        return summary

    for image_path in images:
        image = cv2.imread(str(image_path))

        if image is None:
            print(f"Image: {image_path.name}")
            print("HATA: Goruntu okunamadi (bozuk dosya ya da desteklenmeyen format).\n")
            summary["unreadable"] += 1
            summary["per_image"].append({"file": image_path.name, "status": "unreadable"})
            continue

        detection, mask = detect_stop_sign_debug(image, config)

        if save_debug_mask:
            mask_path = output_dir / "debug_masks" / f"{image_path.stem}_mask.jpg"
            cv2.imwrite(str(mask_path), mask)

        print(f"Image: {image_path.name}")

        if detection is None:
            print("STOP not detected\n")
            summary["not_detected"] += 1
            summary["per_image"].append({"file": image_path.name, "status": "not_detected"})
            continue

        print("STOP detected")
        print(f"Bounding Box: x={detection.x}, y={detection.y}, "
              f"w={detection.w}, h={detection.h}")
        print(f"Center Pixel: ({detection.center_x}, {detection.center_y})\n")

        result_image = draw_detection(image, detection)
        out_path = output_dir / f"{image_path.stem}_result.jpg"
        cv2.imwrite(str(out_path), result_image)

        summary["detected"] += 1
        summary["per_image"].append({
            "file": image_path.name,
            "status": "detected",
            "bounding_box": {"x": detection.x, "y": detection.y,
                              "w": detection.w, "h": detection.h},
            "center": {"x": detection.center_x, "y": detection.center_y},
        })

    return summary


def print_summary(summary: dict) -> None:
    total = summary["total_images"]
    print("=" * 50)
    print("OZET")
    print("=" * 50)
    print(f"Toplam goruntu       : {total}")
    print(f"Tespit edilen        : {summary['detected']}")
    print(f"Tespit edilemeyen    : {summary['not_detected']}")
    print(f"Okunamayan dosya     : {summary['unreadable']}")
    if total > 0:
        rate = summary["detected"] / total * 100
        print(f"Tespit orani         : %{rate:.1f}")
    print("\nNOT: Bu oran ground-truth (dogru etiketlenmis) veri olmadigi icin")
    print("     'accuracy' degil, yalnizca 'tespit edilen/toplam' oranidir.")
    print("     Yanlis pozitifler bu orana dahil DEGILDIR; manuel kontrol gerekir.")


def _hsv_triplet(values: List[str]) -> Tuple[int, int, int]:
    if len(values) != 3:
        raise argparse.ArgumentTypeError("HSV degeri 3 sayi olmali: H S V")
    return tuple(int(v) for v in values)  # type: ignore[return-value]


def build_config(args: argparse.Namespace) -> DetectionConfig:
    """CLI argumanlarindan bir DetectionConfig olusturur; verilmeyenler icin varsayilan kalir."""
    config = DetectionConfig()
    if args.lower_red1:
        config.lower_red_1 = tuple(args.lower_red1)
    if args.upper_red1:
        config.upper_red_1 = tuple(args.upper_red1)
    if args.lower_red2:
        config.lower_red_2 = tuple(args.lower_red2)
    if args.upper_red2:
        config.upper_red_2 = tuple(args.upper_red2)
    if args.min_area_ratio is not None:
        config.min_area_ratio = args.min_area_ratio
    if args.max_area_ratio is not None:
        config.max_area_ratio = args.max_area_ratio
    return config


def main() -> None:
    parser = argparse.ArgumentParser(description="STOP trafik isareti tespiti (renk tabanli)")
    parser.add_argument("--dataset", default="dataset", help="Dataset klasoru (varsayilan: dataset/)")
    parser.add_argument("--output", default="outputs", help="Cikti klasoru (varsayilan: outputs/)")
    parser.add_argument("--debug-mask", action="store_true",
                         help="Her goruntu icin temizlenmis kirmizi maskeyi de outputs/debug_masks/ altina kaydet")

    hsv_group = parser.add_argument_group("HSV esik ayari (gercek dataset'e gore kalibrasyon icin)")
    d = DEFAULT_CONFIG
    hsv_group.add_argument("--lower-red1", nargs=3, type=int, metavar=("H", "S", "V"),
                            help=f"Dusuk Hue araligi alt sinir (varsayilan: {' '.join(map(str, d.lower_red_1))})")
    hsv_group.add_argument("--upper-red1", nargs=3, type=int, metavar=("H", "S", "V"),
                            help=f"Dusuk Hue araligi ust sinir (varsayilan: {' '.join(map(str, d.upper_red_1))})")
    hsv_group.add_argument("--lower-red2", nargs=3, type=int, metavar=("H", "S", "V"),
                            help=f"Yuksek Hue araligi alt sinir (varsayilan: {' '.join(map(str, d.lower_red_2))})")
    hsv_group.add_argument("--upper-red2", nargs=3, type=int, metavar=("H", "S", "V"),
                            help=f"Yuksek Hue araligi ust sinir (varsayilan: {' '.join(map(str, d.upper_red_2))})")
    hsv_group.add_argument("--min-area-ratio", type=float, default=None,
                            help=f"Minimum kontur/goruntu alan orani (varsayilan: {d.min_area_ratio})")
    hsv_group.add_argument("--max-area-ratio", type=float, default=None,
                            help=f"Maksimum kontur/goruntu alan orani (varsayilan: {d.max_area_ratio})")

    args = parser.parse_args()

    config = build_config(args)
    dataset_dir = Path(args.dataset)
    output_dir = Path(args.output)

    summary = process_dataset(dataset_dir, output_dir, config, save_debug_mask=args.debug_mask)
    print_summary(summary)

    output_dir.mkdir(parents=True, exist_ok=True)
    with open(output_dir / "results.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(f"\nDetayli sonuclar '{output_dir / 'results.json'}' dosyasina kaydedildi.")


if __name__ == "__main__":
    main()
