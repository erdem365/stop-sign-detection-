"""
config.py
----------
Tespit pipeline'inin ayarlanabilir esik degerlerini tek bir yerde toplar.

Gercek dataset uzerinde calisildiginda HSV esiklerinin ince ayara ihtiyaci
olmasi beklenir (farkli kamera/aydinlatma kosullari). Bu modul, degerleri
kod icinde degistirmeden komut satirindan (main.py --lower-red1 ... gibi)
veya baska bir script'ten override edebilmeyi saglar.
"""

from dataclasses import dataclass, field
from typing import Tuple

import numpy as np

HsvTriplet = Tuple[int, int, int]


@dataclass
class DetectionConfig:
    """STOP tespiti icin tum ayarlanabilir esik degerlerini tutar."""

    # --- HSV kirmizi renk esikleri -----------------------------------------
    # Kirmizi, HSV'de Hue ekseninin iki ucunda yer alir; bu yuzden iki ayri
    # aralik tanimlanip birlestirilir.
    #
    # Bu degerler, 198 gercek goruntuden olusan bir dogrulama seti uzerinde
    # kalibre edilmistir (bkz. README "Results" ve rapor Bolum 7-8). Daha
    # sıkı bir başlangıç eşiği (S>=100, V>=70) %80.3 accuracy / %72.4 recall
    # veriyordu; soluk/gölgeli kırmızıların coğu extent filtresine takılıyordu
    # (bkz. rapor "Sinirliliklar" -- ornek: 10.jpg). Saturation/Value alt
    # sınırlari gevşetilince (S>=70, V>=50) recall %83.7'ye çıtı, precision
    # hafifçe düştü (%85.5 -> %83.7) -- bu bilinen bir ödünlesimdir.
    lower_red_1: HsvTriplet = (0, 70, 50)
    upper_red_1: HsvTriplet = (10, 255, 255)
    lower_red_2: HsvTriplet = (170, 70, 50)
    upper_red_2: HsvTriplet = (180, 255, 255)

    # --- Morfolojik işlem ayarları ------------------------------------------
    morph_kernel_size: int = 5
    morph_open_iterations: int = 1
    morph_close_iterations: int = 2

    # --- Kontur filtreleme eşikleri (görüntü boyutuna oransal) --------------
    min_area_ratio: float = 0.001    # görüntü alanının en az %0.1'i
    max_area_ratio: float = 0.5      # görüntü alanının en fazla %50'si
    min_aspect_ratio: float = 0.6    # STOP oktagonal -> genişlik/yukseklik ~1
    max_aspect_ratio: float = 1.6
    min_extent: float = 0.55         # kontur alanı / bounding box alanı

    def red_ranges(self) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """HSV esiklerini cv2.inRange icin numpy array'lerine dönüştürür."""
        return (
            np.array(self.lower_red_1),
            np.array(self.upper_red_1),
            np.array(self.lower_red_2),
            np.array(self.upper_red_2),
        )


DEFAULT_CONFIG = DetectionConfig()
