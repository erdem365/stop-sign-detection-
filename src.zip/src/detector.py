"""
detector.py
------------
STOP trafik işareti için renk tabanlı (HSV) tespit fonksiyonları.

Pipeline:
    BGR -> HSV -> Kırmızı Maske -> Morfolojik İşlemler ->
    Kontur Tespiti -> Kontur Filtreleme -> Bounding Box -> Merkez Koordinatı

Tum eşik degerleri config.py icindeki DetectionConfig uzerinden gelir;
bu sayede degerler kod degistirilmeden (ornegin main.py --lower-red1 gibi
CLI argumanlariyla) ayarlanabilir.
"""

from dataclasses import dataclass
from typing import List, Optional, Tuple

import cv2
import numpy as np

from src.config import DEFAULT_CONFIG, DetectionConfig


@dataclass
class Detection:
    """Tek bir STOP tespiti sonucunu tutar."""
    x: int
    y: int
    w: int
    h: int
    center_x: int
    center_y: int
    contour_area: float
    extent: float
    aspect_ratio: float


def load_image(image_path: str) -> Optional[np.ndarray]:
    """Görüntüyü diskten okur. Başarısız olursa None döner (crash etmez)."""
    return cv2.imread(image_path)


def create_red_mask(hsv_image: np.ndarray, config: DetectionConfig = DEFAULT_CONFIG) -> np.ndarray:
    """HSV görüntüsünden iki aralığı birleştirerek kırmızı renk maskesi üretir."""
    lower1, upper1, lower2, upper2 = config.red_ranges()
    mask1 = cv2.inRange(hsv_image, lower1, upper1)
    mask2 = cv2.inRange(hsv_image, lower2, upper2)
    return cv2.bitwise_or(mask1, mask2)


def process_mask(mask: np.ndarray, config: DetectionConfig = DEFAULT_CONFIG) -> np.ndarray:
    """
    Morfolojik işlemlerle maskedeki gürültüyü temizler.

    - Opening (erode->dilate): küçük gürültü benekli pikselleri siler.
    - Closing (dilate->erode): tabela içindeki beyaz harf/kenarlardan dogan
      küçük deliklerin kapatilmasini saglar, boylece kontur butun kalir.
    """
    k = config.morph_kernel_size
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    opened = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=config.morph_open_iterations)
    closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, kernel, iterations=config.morph_close_iterations)
    return closed


def _score_candidate(
    contour: np.ndarray, image_area: float, config: DetectionConfig
) -> Optional[Detection]:
    """Bir konturu STOP adayı olarak degerlendirir; uygunsa Detection döner."""
    area = cv2.contourArea(contour)
    area_ratio = area / image_area

    if area_ratio < config.min_area_ratio or area_ratio > config.max_area_ratio:
        return None

    x, y, w, h = cv2.boundingRect(contour)
    if w == 0 or h == 0:
        return None

    aspect_ratio = w / h
    if aspect_ratio < config.min_aspect_ratio or aspect_ratio > config.max_aspect_ratio:
        return None

    bbox_area = w * h
    extent = area / bbox_area if bbox_area > 0 else 0
    if extent < config.min_extent:
        return None

    center_x = x + w // 2
    center_y = y + h // 2

    return Detection(
        x=x, y=y, w=w, h=h,
        center_x=center_x, center_y=center_y,
        contour_area=area, extent=extent, aspect_ratio=aspect_ratio,
    )


def find_stop_sign(
    mask: np.ndarray,
    image_shape: Tuple[int, int],
    config: DetectionConfig = DEFAULT_CONFIG,
) -> Optional[Detection]:
    """
    Temizlenmiş maskeden konturlari cıkarır, filtreler ve en iyi adayı seçer.

    Birden fazla kırmızı bölge varsa (örneğin arka planda başka kırmızı
    nesneler), filtrelerden geçen adaylar arasından EN BUYUK alanlı olan
    STOP tabelasi olarak seçilir -- tabela genelde kameraya en yakın/en
    belirgin kırmızı nesne olduğu için bu kabul edilebilir bir sezgiseldir,
    fakat kesin degildir (bkz. README "Sinirliliklar").
    """
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None

    image_area = image_shape[0] * image_shape[1]
    candidates: List[Detection] = []
    for contour in contours:
        detection = _score_candidate(contour, image_area, config)
        if detection is not None:
            candidates.append(detection)

    if not candidates:
        return None

    return max(candidates, key=lambda d: d.contour_area)


def calculate_center(x: int, y: int, w: int, h: int) -> Tuple[int, int]:
    """Bounding box'ın merkez piksel koordinatını hesaplar (integer)."""
    center_x = int(x + w / 2)
    center_y = int(y + h / 2)
    return center_x, center_y


def draw_detection(image: np.ndarray, detection: Detection) -> np.ndarray:
    """Bounding box, merkez nokta ve koordinat bilgisini görüntüsü uzerine çizer."""
    output = image.copy()
    x, y, w, h = detection.x, detection.y, detection.w, detection.h

    cv2.rectangle(output, (x, y), (x + w, y + h), (0, 255, 0), 2)
    cv2.circle(output, (detection.center_x, detection.center_y), 5, (0, 0, 255), -1)

    label = f"STOP ({detection.center_x}, {detection.center_y})"
    label_y = y - 10 if y - 10 > 10 else y + h + 20
    cv2.putText(
        output, label, (x, label_y),
        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2, cv2.LINE_AA,
    )
    return output


def detect_stop_sign(
    image: np.ndarray, config: DetectionConfig = DEFAULT_CONFIG
) -> Optional[Detection]:
    """Tek bir görüntünün üzerinde tam pipeline'i calıştırır."""
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    mask = create_red_mask(hsv, config)
    mask = process_mask(mask, config)
    return find_stop_sign(mask, image.shape[:2], config)


def detect_stop_sign_debug(
    image: np.ndarray, config: DetectionConfig = DEFAULT_CONFIG
) -> Tuple[Optional[Detection], np.ndarray]:
    """
    detect_stop_sign ile aynı pipeline'i calıştırır, ek olarak temizlenmiş
    ikili (binary) maskeyi de döner. HSV esiklerini kalibre ederken hangi
    bolgelerin "kırmızı" sayıldığını görsel olarak incelemek icin kullanışlıdır
    (bkz. main.py --debug-mask).
    """
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    mask = create_red_mask(hsv, config)
    mask = process_mask(mask, config)
    detection = find_stop_sign(mask, image.shape[:2], config)
    return detection, mask
